KNOWN BUGS/BROKEN:
    The shaders are not implimented. I render out the verticies just using dots as a comprimise, I couldn't get the shaders working. However, the scene does get rendered through dots.



COMPILE INSTRUCTIONS:
    Just run make and then ./main